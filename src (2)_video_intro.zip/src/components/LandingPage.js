import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaVideo, FaMicrophone, FaClock, FaLightbulb, FaCloudDownloadAlt, FaStopCircle } from 'react-icons/fa';

function LandingPage() {
  const navigate = useNavigate();

  const navigateToRecordPage = () => {
    navigate('/record');
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-500 to-purple-600 text-white">
      <div className="max-w-4xl w-full px-6 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">Video Introduction Recorder</h1>
        <div className="rounded-full bg-white p-8 mb-8 mx-auto" style={{ boxShadow: '0px 8px 15px rgba(0, 0, 0, 0.1)' }}>
          <FaVideo size={120} className="text-gray-800" />
        </div>
        <ul className="text-lg text-left mb-8 max-w-lg mx-auto">
          <li className="mb-4 flex items-start">
            <FaVideo className="mr-3 mt-1 text-gray-200" size={24} />
            <span>Record, pause, resume, and stop video</span>
          </li>
          <li className="mb-4 flex items-start">
            <FaMicrophone className="mr-3 mt-1 text-gray-200" size={24} />
            <span>Record with or without audio</span>
          </li>
          <li className="mb-4 flex items-start">
            <FaClock className="mr-3 mt-1 text-gray-200" size={24} />
            <span>Set dynamic recording time with automatic stop</span>
          </li>
          <li className="mb-4 flex items-start">
            <FaStopCircle className="mr-3 mt-1 text-gray-200" size={24} />
            <span>Emergency stop recording button</span>
          </li>
          <li className="mb-4 flex items-start">
            <FaLightbulb className="mr-3 mt-1 text-gray-200" size={24} />
            <span>Record in dark or light mode</span>
          </li>
          <li className="mb-4 flex items-start">
            <FaCloudDownloadAlt className="mr-3 mt-1 text-gray-200" size={24} />
            <span>Download recorded video</span>
          </li>
        </ul>
        <button
          className={`bg-white text-gray-800 px-8 py-4 rounded-lg hover:bg-gray-300 text-xl mb-4`}
          onClick={navigateToRecordPage}
        >
          Start Recording
        </button>
      </div>
    </div>
  );
}

export default LandingPage;
