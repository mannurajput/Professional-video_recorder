import React, { useState, useRef, useEffect } from 'react';
import Webcam from 'react-webcam';
import { FaPlay, FaPause, FaSyncAlt, FaChevronUp, FaChevronDown } from 'react-icons/fa';
import { MdDarkMode } from "react-icons/md";
import { MdOutlineDarkMode } from "react-icons/md";
import { GiStopSign } from "react-icons/gi";
import { useNavigate } from 'react-router-dom';
import { CiMicrophoneOff } from "react-icons/ci";
import { CiMicrophoneOn } from "react-icons/ci";
import { MdOutlineSaveAlt } from "react-icons/md";
import { FaSquare } from "react-icons/fa";
function RecordPage() {
  const [recording, setRecording] = useState(false);
  const [paused, setPaused] = useState(false);
  const [isAudio, setIsAudio] = useState(true);
  const [isDark, setIsDark] = useState(false);
  const [time, setTime] = useState(120); // Adjusted for testing purposes
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [stream, setStream] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null); // To store recorded video URL
  const [mirrorEffect, setMirrorEffect] = useState(true); // State for mirror effect
  const webcamRef = useRef(null);
  const videoRef = useRef(null);
  const timerRef = useRef(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    getUserMedia();
  }, [isAudio]); // Re-initialize stream when isAudio changes

  const getUserMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: isAudio });
      webcamRef.current.srcObject = stream;
      setStream(stream);
      return stream;
    } catch (err) {
      console.error('Error accessing webcam: ', err);
    }
  };

  const startRecording = (stream) => {
    if (!stream) {
      console.error('Stream not available');
      return;
    }

    const options = { mimeType: 'video/webm; codecs=vp9' };
    const mediaRecorder = new MediaRecorder(stream, options);
    const chunks = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunks.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
    };

    mediaRecorder.start();
    setMediaRecorder(mediaRecorder);
    setRecording(true);
    setPaused(false);

    timerRef.current = setInterval(() => {
      setTime(prevTime => {
        if (prevTime <= 1) {
          clearInterval(timerRef.current);
          stopRecording();
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);
  };

  const pauseRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.pause();
      setPaused(true);
      clearInterval(timerRef.current);
    }
  };

  const resumeRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.resume();
      setPaused(false);
      timerRef.current = setInterval(() => {
        setTime(prevTime => {
          if (prevTime <= 1) {
            clearInterval(timerRef.current);
            stopRecording();
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
      setMediaRecorder(null); // Clear mediaRecorder reference
    }
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null); // Clear stream reference
    }
    setRecording(false);
    setPaused(false);
    clearInterval(timerRef.current);
    setTime(120); // Reset time for next recording
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const toggleAudio = async () => {
    setIsAudio(prevIsAudio => !prevIsAudio);
    if (recording) {
      stopRecording();
      const newStream = await getUserMedia();
      startRecording(newStream);
    }
  };

  const handleRetake = async () => {
    setVideoUrl(null); // Clear recorded video URL
    setTime(120); // Reset timer
    stopRecording(); // Stop any existing recording
    const newStream = await getUserMedia(); // Reinitialize the stream and wait for it to complete
    startRecording(newStream); // Start recording again
  };

 

  const toggleMirrorEffect = () => {
    setMirrorEffect(prev => !prev); // Toggle mirror effect state
  };
  
  const handleDownload = () => {
    // Create a temporary anchor element
    const downloadLink = document.createElement('a');
    downloadLink.href = videoUrl;
    downloadLink.download = 'video.mp4'; // Set the filename for download
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };
  const toggleDark = () => {
    setIsDark(prev => !prev); // Toggle mirror effect state
  };
  const increaseTime = () => {
    setTime(prevTime => prevTime + 10);
  };

  const decreaseTime = () => {
    if (time > 10) {
      setTime(prevTime => prevTime - 10);
    }
  };

  return (
    <div className={`flex flex-col items-center justify-center h-screen ${isDark ? 'bg-black text-red-500' : 'bg-white text-gray-800'}`}>
    <h1 className="text-4xl font-bold mb-8 animate-pulse">Record Your Video Introduction</h1>
    <div className="relative w-full max-w-3xl">
     
        <div className={`absolute top-0 left-[-130px] bottom-0 h-[362px] shadow-lg w-24 ${isDark ? 'bg-gray-700' : 'bg-gray-200'} rounded-md backdrop-filter backdrop-blur-lg flex flex-col justify-center items-center : ''}`}>
          {isDark ? (
            <MdOutlineDarkMode onClick={toggleDark} size={40} className='cursor-pointer mb-4 text-red-500' />
          ) : (
            <MdDarkMode onClick={toggleDark} size={40} className='cursor-pointer mb-4 text-gray-800' />
          )}
     
          {/* <button onClick={decreaseTime} className="bg-red-500 shadow-lg text-white p-4 rounded-full shadow-xl hover:bg-red-700 transition duration-300" disabled={recording}>
            <FaChevronDown size={20} />
          </button> */}
          <button 
      onClick={stopRecording} 
      className={`my-3 shadow-lg text-white p-4 rounded-full shadow-xl transition duration-300 cursor-pointer ${recording ? 'bg-red-500 hover:bg-red-700' : 'bg-gray-500 cursor-not-allowed'}`} 
      disabled={!recording}
    >
      <GiStopSign size={20} /> 
    </button>
    <button
      onClick={handleDownload}
      className={`bg-red-500 my-3 shadow-lg text-white p-4 rounded-full shadow-xl mb-4  transition duration-300 ${!videoUrl ? 'bg-gray-500 cursor-not-allowed' : ''}`}
      disabled={!videoUrl}
    >
      <MdOutlineSaveAlt size={20} />
    </button>
        </div>
      
      {!videoUrl ? (
        <Webcam ref={webcamRef} style={{ transform: mirrorEffect ? 'scaleX(-1)' : 'scaleX(1)', width: '887px', height: '362px' }} className="mb-6 rounded-lg shadow-xl object-cover border border-gray-300" />
      ) : (
        <video ref={videoRef} src={videoUrl} style={{ width: '887px', height: '362px' }} className="mb-6 rounded-lg shadow-xl object-cover border border-gray-300" controls>
          Your browser does not support the video tag.
        </video>
      )}
      <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 flex space-x-6">
        {!recording && !videoUrl && (
          <button onClick={() => startRecording(stream)} className="bg-red-500 shadow-lg text-white p-4 rounded-full shadow-xl hover:bg-red-700 transition duration-300">
            <FaSquare size={35} />
          </button>
        )}
        {recording && !paused && (
          <button onClick={pauseRecording} className="bg-yellow-500 shadow-lg text-white p-4 rounded-full shadow-xl hover:bg-yellow-700 transition duration-300">
            <FaPause size={40} />
          </button>
        )}
        {paused && (
          <button onClick={resumeRecording} className="bg-green-500 shadow-lg text-white p-4 rounded-full shadow-xl hover:bg-green-700 transition duration-300">
            <FaPlay size={40} className="ml-1" />
          </button>
        )}
      </div>
      {videoUrl && (
        <div className="absolute bottom-[-40px] flex justify-between w-full px-6">
          <button onClick={handleRetake} className="bg-yellow-500 text-white px-4 py-2 rounded-md shadow-md hover:bg-yellow-700 transition duration-300">
            Retake
          </button>

        </div>
      )}
      {!videoUrl && (
        <div className={`absolute top-0 right-[-130px] bottom-0 h-[362px] shadow-lg w-24 ${isDark ? 'bg-gray-700' : 'bg-gray-200'} rounded-md backdrop-filter backdrop-blur-lg flex flex-col justify-center items-center ${recording ? 'pointer-events-none opacity-50' : ''}`}>
          <FaSyncAlt onClick={toggleMirrorEffect} size={40} className={`cursor-pointer mb-4 ${mirrorEffect ? 'text-red-500' : 'text-gray-500'}`} />
          <button onClick={increaseTime} className="bg-red-500 shadow-lg text-white p-4 rounded-full shadow-xl mb-4 hover:bg-red-700 transition duration-300" disabled={recording}>
            <FaChevronUp size={20} />
          </button>
          <button onClick={decreaseTime} className="bg-red-500 shadow-lg text-white p-4 rounded-full shadow-xl hover:bg-red-700 transition duration-300" disabled={recording}>
            <FaChevronDown size={20} />
          </button>
          <button onClick={toggleAudio} className={`bg-${isAudio ? 'red' : 'gray'}-700 mt-4 shadow-lg text-white p-4 rounded-full shadow-xl hover:bg-${isAudio ? 'red' : 'gray'}-700 transition duration-300`} disabled={recording}>
            {isAudio ? <CiMicrophoneOn size={20} /> : <CiMicrophoneOff size={20} />}
          </button>
        </div>
      )}
    </div>
    <p className="text-2xl font-bold mt-6 animate-pulse">Recording Time: {formatTime(time)}</p>
  </div>
  
  
  );
}

export default RecordPage;
